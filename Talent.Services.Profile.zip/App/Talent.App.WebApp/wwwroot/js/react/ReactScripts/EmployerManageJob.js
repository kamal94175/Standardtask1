﻿import React from 'react';
import ReactDOM from 'react-dom';
import ManageJob from './Employer/ManageJob/ManageJob.jsx';

ReactDOM.render(
    <ManageJob />,
    document.getElementById('employer-job-manage')
)