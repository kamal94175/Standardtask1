﻿/*This is modal Popup for sending email invitation to clients can also change ResetPassword from here*/

import _ from 'lodash'
import React from 'react'
import { Button, Header, Icon, Image, Modal } from 'semantic-ui-react';
import { Form } from 'semantic-ui-react';
import Cookies from 'js-cookie';

class InviteClientModal extends React.Component {
    constructor(props) {
        super(props);
       
    }

    render() {

    }
}

export default InviteClientModal
