﻿/*Add Client modal on ManageClient page*/

import _ from 'lodash'
import React from 'react'
import { Button, Modal } from 'semantic-ui-react';
import { Form } from 'semantic-ui-react';
import Cookies from 'js-cookie';

class AddClient extends React.Component {
    constructor(props) {
        super(props);
      
    }

    

    render() {
        
    }
}

export default AddClient
