﻿import React from 'react';
import { Loader, Popup, Icon, Header, Button } from 'semantic-ui-react';
import Modal from 'semantic-ui-react/dist/commonjs/modules/Modal/Modal';

export default class NotesAndComments extends React.Component {
    constructor(props) {
        super(props);


       
    }
  
  
    
    render() {
        
 
    }
}