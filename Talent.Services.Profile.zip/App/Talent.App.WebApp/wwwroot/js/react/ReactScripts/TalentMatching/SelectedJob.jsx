﻿import React from 'react';

export default class SelectedJob extends React.Component {
    constructor(props) {
        super(props);

    }

   
    render() {
     
        
    }
}