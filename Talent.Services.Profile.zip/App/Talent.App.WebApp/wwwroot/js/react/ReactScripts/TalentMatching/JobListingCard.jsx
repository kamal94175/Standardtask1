﻿import React from 'react';

export default class JobListingCard extends React.Component {
    constructor(props) {
        super(props);
   
    }


    render() {
      
    }
}