﻿import React from 'react';
import { Loader, Popup, Icon, Header } from 'semantic-ui-react';
import { DetailsModal } from './DetailsModal.jsx';
import ReactPlayer from 'react-player';
import NotesAndComments from './NotesAndComments.jsx';

export default class TalentCard extends React.Component {
    constructor(props) {
        super(props);

       
    }

    render() {
       
    }
}