﻿import React from 'react'
import ReactDOM from 'react-dom'
import { Modal, Button } from 'semantic-ui-react'
import ReactPlayer from 'react-player'

export class DetailsModal extends React.Component {
    constructor(props) {
        super(props)
    };

    render() {
        
    }
}
