﻿import React from 'react';
import ReactDOM from 'react-dom';
import CreateJob from './Employer/CreateJob/CreateJob.jsx';

ReactDOM.render(
    <CreateJob />,
    document.getElementById('employer-job-new')
)