﻿import React from 'react';
import ReactDOM from 'react-dom';
import App from './Layout/App.jsx';

ReactDOM.render(
    <App />,
    document.getElementById('home')
)