﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Talent.Services.Profile.Models.Profile
{
    public class DescriptionViewModel
    {
        public string PersonId { get; set; }
        public string Description { get; set; }
    }
}
