﻿namespace Talent.Services.Listing
{
    internal class AuthenticateUserHandler
    {
    }
}