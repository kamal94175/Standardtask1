﻿using RawRabbit.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace Talent.Common.RabbitMq
{
    public class RabbitMqOptions: RawRabbitConfiguration
    {
    }
}
