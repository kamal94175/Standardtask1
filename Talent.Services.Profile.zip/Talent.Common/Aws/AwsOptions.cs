﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Talent.Common.Aws
{
    public class AwsOptions
    {
        public string AwsAccessKey { get; set; }
        public string AwsSerectKey { get; set; }
    }
}
