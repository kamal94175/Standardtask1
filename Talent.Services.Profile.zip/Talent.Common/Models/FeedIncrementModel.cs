﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Talent.Common.Models
{
    public class FeedIncrementModel
    {
        public int Position { get; set; }
        public int Number { get; set; }
    }
}
